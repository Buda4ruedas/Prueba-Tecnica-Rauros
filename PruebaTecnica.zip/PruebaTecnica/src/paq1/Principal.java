package paq1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Clase Principal que gestiona el registro y administración de paquetes.
 *
 * @author Alejandro Plaza
 * @version 1.0
 */
public class Principal {

	/** Lista de paquetes registrados. */
	static ArrayList<Paquete> paquetes = new ArrayList<>();
	/** Scanner para la entrada de datos del usuario. */
	static Scanner scLine = new Scanner(System.in);

	/**
	 * Método principal que gestiona el menú de la aplicación.
	 * @param args Argumentos de línea de comandos.
	 */
	public static void main(String[] args) {
		boolean menu = false;
		while (!menu) {
			int opcion;
			do {
				System.out.println("\n*******GESTION DE PAQUETES *******\n");
				System.out.println("1.- Registrar un paquete");
				System.out.println("2.- Listar todos los paquetes");
				System.out.println("3.- Buscar un paquete");
				System.out.println("4.- Eliminar un paquete");
				System.out.println("5.- Salir\n");

				System.out.println("Elige una opcion (1-5)");
				opcion = gestionErrores();
				if (opcion < 1 || opcion > 5)
					System.out.println("opcion fuera de rango\n");

			} while (opcion < 1 || opcion > 5);

			switch (opcion) {
			case 1:
				registrarPaquete();
				break;
			case 2:
				listarPaquetesRegistrados();
				break;
			case 3:
				buscarUnPaquete();
				break;
			case 4:
				eliminarUnPaquete();
				break;
			case 5:
				System.out.println("¿Seguro que quiere salir?(Si para salir)");
				String a = scLine.nextLine();

				if (a.equalsIgnoreCase("Si")) {
					menu = true;
				}
				break;
			}
		}
		scLine.close();
	}

	/**
	 * Elimina un paquete por su número de seguimiento.
	 */
	private static void eliminarUnPaquete() {
		if (!paquetes.isEmpty()) {
			System.out.println("Introduce el numero de seguimiento del paquete que quieras eliminar");
			int nSeguimiento = numeroIntroducidoCorrecto();
			Paquete paquete = obtenerPaquetePorN(nSeguimiento);
			if (paquete != null) {
				paquetes.remove(paquete);
				System.out.println("Paquete eliminado con éxito");
			} else {
				System.out.println("No se ha encontrado ningún paquete con ese número de seguimiento");
			}
		} else {
			System.out.println("No hay paquetes registrados");
		}
	}

	/**
	 * Busca un paquete por su número de seguimiento.
	 */
	private static void buscarUnPaquete() {
		if (!paquetes.isEmpty()) {
			System.out.println("Introduce el numero de seguimiento del paquete que quieras buscar");
			int nSeguimiento = numeroIntroducidoCorrecto();
			Paquete paquete = obtenerPaquetePorN(nSeguimiento);
			if (paquete != null)
				System.out.println(paquete);
			else
				System.out.println("No se ha encontrado ningún paquete con ese número de seguimiento");
		} else {
			System.out.println("No hay paquetes registrados");
		}
	}

	/**
	 * Devuelve un objeto paquete si tiene el mismo numero de seguimiento que el pasado por parametro
	 * @return Un paquete
	 */
	private static Paquete obtenerPaquetePorN(int nSeguimiento) {

		Paquete paquete = null;
		for (int i = 0; i < paquetes.size(); i++) {
			if (paquetes.get(i).getNumeroSeguimiento() == nSeguimiento) {
				paquete = paquetes.get(i);
				break;
			}
		}
		return paquete;
	}

	/**
	 * Lista todos los paquetes registrados.
	 */
	private static void listarPaquetesRegistrados() {
		if (!paquetes.isEmpty()) {
			System.out.println("Estos son todos los paquetes registrados: \n");
			for (Paquete paquete : paquetes) {
				System.out.println(paquete);
			}
		} else {
			System.out.println("No hay paquetes registrados \n");
		}
	}

	/**
	 * Registra un nuevo paquete ingresando su número de seguimiento, dirección y peso.
	 */
	private static void registrarPaquete() {
		int numeroDeSeguimiento;
		int peso;
		boolean numeroCorrecto;
		do {
			System.out.println("Ingrese el numero de seguimiento del paquete (valor mayor de 0)");
			numeroDeSeguimiento = numeroIntroducidoCorrecto();
			numeroCorrecto = true;
			for (Paquete paquete : paquetes) {
				if (paquete.getNumeroSeguimiento() == numeroDeSeguimiento) {
					System.out.println("Ya existe un paquete con ese número de seguimiento");
					numeroCorrecto = false;
					break;
				}
			}
		} while (!numeroCorrecto);

		System.out.println("Introduce la dirección del paquete");
		String direccion = scLine.nextLine();

		System.out.println("Ingrese el peso del paquete (valor mayor de 0)");
		peso = numeroIntroducidoCorrecto();

		Paquete paquete = new Paquete(numeroDeSeguimiento, direccion, peso);
		paquetes.add(paquete);

		System.out.println("Paquete registrado con éxito \n");
	}

	/**
	 * Maneja la entrada del usuario para evitar errores de formato.
	 * @return Un número entero válido.
	 */
	private static int gestionErrores() {
		while (true) {
			try {
				return Integer.parseInt(scLine.nextLine().trim());
			} catch (NumberFormatException e) {
				System.out.println("Error: Ingrese un número válido.");
			}
		}
	}

	/**
	 * Valida que el número ingresado sea mayor a 0.
	 * @return Un número entero mayor a 0.
	 */
	private static int numeroIntroducidoCorrecto() {
		int numeroCorrecto;
		do {
			numeroCorrecto = gestionErrores();
			if (numeroCorrecto <= 0)
				System.out.println("Valor erróneo. Prueba otra vez");
		} while (numeroCorrecto <= 0);

		return numeroCorrecto;
	}
}
