package paq1;

import java.util.Objects;

/**
 * Representa un paquete con número de seguimiento, dirección de entrega, peso y coste de envío.
 * 
 * @author  Alejandro Plaza
 * @version 1.0
 */
public class Paquete {

    private int numeroSeguimiento;
    private String direccionDeEntrega;
    private int peso;
    private int coste;

    /**
     * Constructor de la clase Paquete.
     * 
     * @param numeroSeguimiento Número de seguimiento único del paquete.
     * @param direccionDeEntrega Dirección donde se entregará el paquete.
     * @param peso Peso del paquete en kilogramos.
     */
    public Paquete(int numeroSeguimiento, String direccionDeEntrega, int peso) {
        super();
        this.numeroSeguimiento = numeroSeguimiento;
        this.direccionDeEntrega = direccionDeEntrega;
        this.peso = peso;
        calcularCoste();
    }

    /**
     * Calcula el coste de envío del paquete en función de su peso.
     * 
     * - Hasta 5 kg: 10 unidades monetarias.
     * - Entre 6 y 20 kg: 25 unidades monetarias.
     * - Más de 20 kg: 50 unidades monetarias.
     */
    private void calcularCoste() {
        if (this.peso <= 5)
            this.coste = 10;
        else if (this.peso > 5 && this.peso <= 20)
            this.coste = 25;
        else
            this.coste = 50;
    }

    /**
     * Devuelve una representación en cadena del paquete.
     * 
     * @return Cadena con la información del paquete.
     */
    @Override
    public String toString() {
        return "Paquete con numero de seguimiento: " + numeroSeguimiento +
               ", direccion de entrega: " + direccionDeEntrega +
               ", peso: " + peso + "Kg, coste: " + coste + "€";
    }

    /**
     * Obtiene el número de seguimiento del paquete.
     * 
     * @return Número de seguimiento.
     */
    public int getNumeroSeguimiento() {
        return numeroSeguimiento;
    }

    /**
     * Establece el número de seguimiento del paquete.
     * 
     * @param numeroSeguimiento Número de seguimiento a asignar.
     */
    public void setNumeroSeguimiento(int numeroSeguimiento) {
        this.numeroSeguimiento = numeroSeguimiento;
    }

}
